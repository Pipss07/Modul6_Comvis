"""
utils/blending.py
------------------
Modul multi-band blending menggunakan Gaussian dan Laplacian pyramid.

Multi-band blending:
- Memblend gambar di berbagai frekuensi secara terpisah
- Frekuensi rendah (area warna besar): blending dengan transisi lebih lebar
- Frekuensi tinggi (detail/tepi): blending dengan transisi lebih tajam
- Menghasilkan seam yang tidak terlihat, bahkan di area bertekstur tinggi

Referensi: Burt & Adelson (1983) "A Multiresolution Spline With Application
            to Image Mosaics"
"""

import cv2
import numpy as np


def build_gaussian_pyramid(img, levels):
    """
    Bangun Gaussian pyramid dari gambar.
    Level 0 = gambar asli, setiap level lebih kecil 2x.
    """
    pyramid = [img.astype(np.float32)]
    for _ in range(levels - 1):
        img = cv2.pyrDown(img)
        pyramid.append(img.astype(np.float32))
    return pyramid


def build_laplacian_pyramid(img, levels):
    """
    Bangun Laplacian pyramid = detail per level frekuensi.
    LP[i] = GP[i] - upsample(GP[i+1])
    """
    gauss_pyr = build_gaussian_pyramid(img, levels)
    laplacian_pyr = []
    
    for i in range(levels - 1):
        size = (gauss_pyr[i].shape[1], gauss_pyr[i].shape[0])
        expanded = cv2.pyrUp(gauss_pyr[i + 1], dstsize=size)
        laplacian = cv2.subtract(gauss_pyr[i], expanded.astype(np.float32))
        laplacian_pyr.append(laplacian)
    
    # Level terakhir adalah gambar low-res dari Gaussian pyramid
    laplacian_pyr.append(gauss_pyr[-1])
    
    return laplacian_pyr


def reconstruct_from_laplacian(laplacian_pyr):
    """
    Rekonstruksi gambar dari Laplacian pyramid.
    Kebalikan dari build_laplacian_pyramid.
    """
    img = laplacian_pyr[-1].astype(np.float32)
    
    for i in range(len(laplacian_pyr) - 2, -1, -1):
        size = (laplacian_pyr[i].shape[1], laplacian_pyr[i].shape[0])
        img = cv2.pyrUp(img, dstsize=size)
        img = cv2.add(img, laplacian_pyr[i].astype(np.float32))
    
    return img


def multi_band_blend(img1, img2, mask, levels=6):
    """
    Multi-band blending antara dua gambar menggunakan mask.
    
    Args:
        img1: Gambar kiri (BGR, float32 atau uint8)
        img2: Gambar kanan (BGR, float32 atau uint8)
        mask: Mask blending [0=img1 saja, 255=img2 saja, 128=50/50]
              Harus single channel atau 3 channel, range [0, 255]
        levels: Jumlah level pyramid (default 6)
    Returns:
        Gambar hasil blending
    """
    # Konversi ke float32
    img1_f = img1.astype(np.float32)
    img2_f = img2.astype(np.float32)
    
    # Normalisasi mask ke [0, 1]
    if len(mask.shape) == 2:
        mask_3ch = np.stack([mask, mask, mask], axis=-1).astype(np.float32) / 255.0
    else:
        mask_3ch = mask.astype(np.float32) / 255.0
    
    # Sesuaikan levels agar tidak melebihi ukuran gambar
    h, w = img1.shape[:2]
    max_levels = int(np.log2(min(h, w))) - 1
    levels = min(levels, max_levels)
    levels = max(levels, 1)
    
    # Build Laplacian pyramids untuk kedua gambar
    lp1 = build_laplacian_pyramid(img1_f, levels)
    lp2 = build_laplacian_pyramid(img2_f, levels)
    
    # Build Gaussian pyramid untuk mask
    gp_mask = build_gaussian_pyramid(mask_3ch, levels)
    
    # Blend setiap level pyramid
    blended_pyr = []
    for i in range(levels):
        # Resized mask untuk level ini
        m = gp_mask[i]
        
        # Resize LP jika diperlukan (ukuran mungkin berbeda 1 piksel)
        lp2_resized = cv2.resize(lp2[i], (lp1[i].shape[1], lp1[i].shape[0]))
        m_resized = cv2.resize(m, (lp1[i].shape[1], lp1[i].shape[0]))
        
        # Blending per level
        blended = lp1[i] * (1 - m_resized) + lp2_resized * m_resized
        blended_pyr.append(blended)
    
    # Rekonstruksi gambar akhir
    result = reconstruct_from_laplacian(blended_pyr)
    result = np.clip(result, 0, 255).astype(np.uint8)
    
    return result


def create_linear_blend_mask(canvas_shape, x_start, x_end, feather_width=None):
    """
    Buat mask blending linear (feathered) untuk area overlap horizontal.
    
    Args:
        canvas_shape: (height, width) canvas
        x_start: Awal area overlap (koordinat x)
        x_end: Akhir area overlap (koordinat x)
        feather_width: Lebar transisi feathering (None = seluruh overlap)
    Returns:
        Mask float32 [0, 1]
    """
    h, w = canvas_shape[:2]
    mask = np.zeros((h, w), dtype=np.float32)
    
    overlap_w = x_end - x_start
    if overlap_w <= 0:
        return mask
    
    if feather_width is None:
        feather_width = overlap_w
    
    half_feather = feather_width // 2
    center = (x_start + x_end) // 2
    
    # Ramp dari 0 ke 1 di sebelah kiri center
    left_start = max(0, center - half_feather)
    left_end = center
    if left_end > left_start:
        ramp = np.linspace(0, 1, left_end - left_start)
        mask[:, left_start:left_end] = ramp[np.newaxis, :]
    
    # Ramp dari 1 ke 0 di sebelah kanan center (blend ke gambar berikutnya)
    right_start = center
    right_end = min(w, center + half_feather)
    if right_end > right_start:
        ramp = np.linspace(1, 0, right_end - right_start)
        mask[:, right_start:right_end] = ramp[np.newaxis, :]
    
    return mask


def blend_two_images_multiband(canvas, new_img, canvas_mask, new_mask, levels=6):
    """
    Blend gambar baru ke canvas yang sudah ada menggunakan multi-band blending.
    
    Args:
        canvas: Canvas saat ini (BGR uint8)
        new_img: Gambar baru yang akan di-blend
        canvas_mask: Mask valid piksel canvas (0/255)
        new_mask: Mask valid piksel gambar baru (0/255)
        levels: Level pyramid
    Returns:
        Canvas hasil blending
    """
    # Tentukan area overlap
    overlap = (canvas_mask > 0) & (new_mask > 0)
    
    if not np.any(overlap):
        # Tidak ada overlap, gabung langsung
        result = canvas.copy()
        result[new_mask > 0] = new_img[new_mask > 0]
        return result
    
    # Buat blending mask: 0 = canvas, 255 = new_img di area overlap
    blend_mask = np.zeros(canvas.shape[:2], dtype=np.uint8)
    
    # Di area overlap: buat gradasi horizontal
    overlap_cols = np.where(np.any(overlap, axis=0))[0]
    if len(overlap_cols) > 0:
        x_start = int(overlap_cols[0])
        x_end = int(overlap_cols[-1])
        overlap_w = x_end - x_start
        
        if overlap_w > 0:
            gradient = np.linspace(0, 255, overlap_w, dtype=np.uint8)
            rows_with_overlap = np.any(overlap, axis=1)
            blend_mask[np.ix_(rows_with_overlap, overlap_cols)] = gradient[
                :len(overlap_cols)
            ]
    
    # Konversi mask ke float
    blend_mask_f = blend_mask.astype(np.float32) / 255.0
    blend_mask_3ch = np.stack([blend_mask_f] * 3, axis=-1)
    
    # Multi-band blend
    # Pastikan ukuran sama
    h, w = canvas.shape[:2]
    new_img_resized = cv2.resize(new_img, (w, h)) if new_img.shape[:2] != (h, w) else new_img
    
    blended = multi_band_blend(canvas, new_img_resized, blend_mask, levels=levels)
    
    # Area yang hanya ada di canvas atau new_img, tidak perlu blend
    canvas_only = (canvas_mask > 0) & (new_mask == 0)
    new_only = (new_mask > 0) & (canvas_mask == 0)
    
    result = blended.copy()
    result[canvas_only] = canvas[canvas_only]
    result[new_only] = new_img_resized[new_only]
    
    return result


def simple_linear_blend(img1, img2, mask1, mask2):
    """
    Blending sederhana menggunakan linear feathering (fallback dari multi-band).
    Lebih cepat tapi bisa ada ghosting di area bertekstur tinggi.
    """
    result = np.zeros_like(img1)
    
    # Area hanya img1
    only1 = (mask1 > 0) & (mask2 == 0)
    result[only1] = img1[only1]
    
    # Area hanya img2
    only2 = (mask2 > 0) & (mask1 == 0)
    result[only2] = img2[only2]
    
    # Area overlap: linear blend
    overlap = (mask1 > 0) & (mask2 > 0)
    if np.any(overlap):
        # Buat weight dari posisi x (kiri lebih banyak img1, kanan lebih banyak img2)
        overlap_x = np.where(np.any(overlap, axis=0))[0]
        if len(overlap_x) > 0:
            x_min, x_max = overlap_x[0], overlap_x[-1]
            for x in range(x_min, x_max + 1):
                col_overlap = overlap[:, x]
                if np.any(col_overlap):
                    alpha = (x - x_min) / max(1, x_max - x_min)
                    result[col_overlap, x] = (
                        (1 - alpha) * img1[col_overlap, x] +
                        alpha * img2[col_overlap, x]
                    ).astype(np.uint8)
    
    return result
