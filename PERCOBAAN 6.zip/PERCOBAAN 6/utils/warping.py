"""
utils/warping.py
-----------------
Modul proyeksi silindris dan sferis untuk image warping.

Proyeksi cylindrical:
  - Memetakan gambar ke permukaan silinder virtual
  - Cocok untuk panorama horizontal (360° horizontal)
  - Menghilangkan distorsi perspektif di tepi gambar

Proyeksi spherical:
  - Memetakan gambar ke permukaan bola virtual
  - Cocok untuk panorama full-sphere (360° x 180°)
"""

import cv2
import numpy as np


def estimate_focal_length(img):
    """
    Estimasi focal length dari dimensi gambar.
    Asumsi: FOV horizontal ~60 derajat (setara kamera smartphone).
    
    Args:
        img: Gambar input
    Returns:
        Estimasi focal length dalam piksel
    """
    h, w = img.shape[:2]
    # f = w / (2 * tan(FOV/2))
    # Untuk FOV 60°: f ≈ w * 0.866
    fov_rad = np.deg2rad(60)
    f = w / (2 * np.tan(fov_rad / 2))
    return f


def cylindrical_warp(img, focal_length=None):
    """
    Proyeksi silindris: memetakan gambar ke permukaan silinder.
    
    Rumus proyeksi:
        x' = f * arctan(x/f)
        y' = f * y / sqrt(x² + f²)
    
    di mana (x, y) adalah koordinat ternormalisasi dari pusat gambar.
    
    Args:
        img: Gambar input (BGR)
        focal_length: Focal length dalam piksel. Jika None, di-estimasi otomatis.
    Returns:
        Gambar hasil proyeksi silindris
        x_offset: Offset horizontal untuk alignment
    """
    h, w = img.shape[:2]
    
    if focal_length is None:
        focal_length = estimate_focal_length(img)
    
    f = focal_length
    
    # Buat grid koordinat output
    # Koordinat silindris: theta ∈ [-w/(2f), w/(2f)], y_cyl ∈ [-h/2f, h/2f]
    K = np.array([
        [f, 0, w / 2],
        [0, f, h / 2],
        [0, 0, 1]
    ], dtype=np.float32)
    
    # Inverse warp: untuk setiap piksel output, cari piksel input
    # Koordinat output (cylindrical space)
    theta_range = np.arctan(np.array([-w/2, w/2]) / f)
    
    # Buat meshgrid untuk koordinat output
    x_out = np.arange(w, dtype=np.float32)
    y_out = np.arange(h, dtype=np.float32)
    x_grid, y_grid = np.meshgrid(x_out, y_out)
    
    # Konversi ke koordinat silindris ternormalisasi
    x_norm = (x_grid - w / 2) / f
    y_norm = (y_grid - h / 2) / f
    
    # Proyeksi balik ke koordinat 3D
    x_3d = np.sin(x_norm)
    y_3d = y_norm
    z_3d = np.cos(x_norm)
    
    # Proyeksi ke koordinat gambar input
    x_src = (f * x_3d / z_3d) + w / 2
    y_src = (f * y_3d / z_3d) + h / 2
    
    # Warp menggunakan remap (lebih efisien dari loop)
    warped = cv2.remap(
        img,
        x_src.astype(np.float32),
        y_src.astype(np.float32),
        interpolation=cv2.INTER_LINEAR,
        borderMode=cv2.BORDER_CONSTANT,
        borderValue=0
    )
    
    return warped, f


def spherical_warp(img, focal_length=None):
    """
    Proyeksi sferis: memetakan gambar ke permukaan bola.
    
    Rumus proyeksi:
        θ = arctan(x/f)         (azimuth)
        φ = arctan(y/√(x²+f²)) (elevation)
    
    Args:
        img: Gambar input (BGR)
        focal_length: Focal length dalam piksel
    Returns:
        Gambar hasil proyeksi sferis
        focal_length yang digunakan
    """
    h, w = img.shape[:2]
    
    if focal_length is None:
        focal_length = estimate_focal_length(img)
    
    f = focal_length
    
    # Koordinat output
    x_out = np.arange(w, dtype=np.float32)
    y_out = np.arange(h, dtype=np.float32)
    x_grid, y_grid = np.meshgrid(x_out, y_out)
    
    # Sudut spherical
    theta = (x_grid - w / 2) / f  # azimuth
    phi = (y_grid - h / 2) / f    # elevation
    
    # Balik ke koordinat 3D
    x_3d = np.sin(theta) * np.cos(phi)
    y_3d = np.sin(phi)
    z_3d = np.cos(theta) * np.cos(phi)
    
    # Proyeksi ke gambar input
    x_src = (f * x_3d / z_3d) + w / 2
    y_src = (f * y_3d / z_3d) + h / 2
    
    # Mask piksel valid
    valid = (z_3d > 0) & (x_src >= 0) & (x_src < w) & (y_src >= 0) & (y_src < h)
    x_src = np.where(valid, x_src, 0).astype(np.float32)
    y_src = np.where(valid, y_src, 0).astype(np.float32)
    
    warped = cv2.remap(
        img,
        x_src,
        y_src,
        interpolation=cv2.INTER_LINEAR,
        borderMode=cv2.BORDER_CONSTANT,
        borderValue=0
    )
    
    # Mask area tidak valid
    mask = valid.astype(np.uint8) * 255
    warped[mask == 0] = 0
    
    return warped, f


def warp_images(images, projection="cylindrical", focal_length=None):
    """
    Terapkan proyeksi ke semua gambar.
    
    Args:
        images: List gambar BGR
        projection: 'cylindrical' atau 'spherical'
        focal_length: Focal length dalam piksel (None = auto-estimasi)
    Returns:
        List gambar yang sudah diproyeksikan
        focal_length yang digunakan
    """
    print(f"\n[Warping] Proyeksi: {projection.upper()}")
    
    # Estimasi focal length dari gambar pertama jika tidak diberikan
    if focal_length is None:
        focal_length = estimate_focal_length(images[0])
        print(f"[Warping] Estimasi focal length: {focal_length:.1f} px")
    
    warped_images = []
    
    for i, img in enumerate(images):
        if projection == "cylindrical":
            warped, f = cylindrical_warp(img, focal_length)
        elif projection == "spherical":
            warped, f = spherical_warp(img, focal_length)
        else:
            raise ValueError(f"Proyeksi tidak dikenal: {projection}. Gunakan 'cylindrical' atau 'spherical'")
        
        warped_images.append(warped)
        print(f"  [Warp] Gambar {i+1}/{len(images)} ✓")
    
    return warped_images, focal_length


def warp_perspective_with_translation(img, H, canvas_size, offset):
    """
    Warp gambar dengan homografi dan terapkan translasi offset.
    
    Args:
        img: Gambar yang akan di-warp
        H: Matriks homografi 3x3
        canvas_size: (width, height) canvas output
        offset: (tx, ty) translasi
    Returns:
        Gambar yang sudah di-warp pada canvas
    """
    tx, ty = offset
    T = np.array([[1, 0, tx], [0, 1, ty], [0, 0, 1]], dtype=np.float64)
    
    H_translated = T @ H if H is not None else T
    
    warped = cv2.warpPerspective(
        img, H_translated, canvas_size,
        flags=cv2.INTER_LINEAR,
        borderMode=cv2.BORDER_CONSTANT,
        borderValue=0
    )
    return warped


def compute_canvas_size(images, homographies):
    """
    Hitung ukuran canvas yang diperlukan untuk menampung semua gambar setelah warp.
    
    Args:
        images: List gambar
        homographies: List kumulatif homografi per gambar
    Returns:
        canvas_size: (width, height)
        offset: (x_min, y_min) offset translasi minimum
    """
    corners_all = []
    
    for img, H in zip(images, homographies):
        h, w = img.shape[:2]
        corners = np.float32([[0, 0], [w, 0], [w, h], [0, h]]).reshape(-1, 1, 2)
        
        if H is not None:
            corners_t = cv2.perspectiveTransform(corners, H)
        else:
            corners_t = corners
        
        corners_all.append(corners_t.reshape(-1, 2))
    
    all_points = np.vstack(corners_all)
    
    x_min = int(np.floor(all_points[:, 0].min()))
    y_min = int(np.floor(all_points[:, 1].min()))
    x_max = int(np.ceil(all_points[:, 0].max()))
    y_max = int(np.ceil(all_points[:, 1].max()))
    
    canvas_w = x_max - x_min
    canvas_h = y_max - y_min
    
    # Padding sedikit untuk keamanan
    padding = 10
    canvas_w += 2 * padding
    canvas_h += 2 * padding
    
    offset = (-x_min + padding, -y_min + padding)
    
    return (canvas_w, canvas_h), offset
