"""
utils/feature_matching.py
--------------------------
Modul deteksi fitur dan pencocokan antar pasangan gambar.

Menggunakan:
- SIFT (Scale-Invariant Feature Transform) untuk deteksi keypoint
- FLANN-based matcher untuk pencocokan cepat dan akurat  
- Lowe's ratio test untuk filtering false matches
- RANSAC (via findHomography) untuk estimasi homografi yang robust
"""

import cv2
import numpy as np


def create_detector(algorithm="SIFT"):
    """
    Buat detektor fitur.
    
    Args:
        algorithm: 'SIFT' (akurat) atau 'ORB' (cepat, gratis)
    Returns:
        detector object dari OpenCV
    """
    if algorithm == "SIFT":
        try:
            detector = cv2.SIFT_create(nfeatures=0, contrastThreshold=0.04)
            print("  [Detektor] SIFT aktif")
            return detector, "SIFT"
        except AttributeError:
            print("  [Detektor] SIFT tidak tersedia, menggunakan ORB sebagai fallback")
    
    # Fallback ke ORB
    detector = cv2.ORB_create(nfeatures=5000, scaleFactor=1.2, nlevels=8)
    print("  [Detektor] ORB aktif")
    return detector, "ORB"


def create_matcher(algorithm="SIFT"):
    """Buat feature matcher berdasarkan algoritma yang digunakan."""
    if algorithm == "SIFT":
        # FLANN: Fast Library for Approximate Nearest Neighbors
        FLANN_INDEX_KDTREE = 1
        index_params = dict(algorithm=FLANN_INDEX_KDTREE, trees=5)
        search_params = dict(checks=50)
        matcher = cv2.FlannBasedMatcher(index_params, search_params)
    else:
        # BFMatcher lebih cocok untuk ORB (descriptor biner)
        matcher = cv2.BFMatcher(cv2.NORM_HAMMING, crossCheck=False)
    
    return matcher


def detect_and_compute(img, detector):
    """
    Deteksi keypoint dan hitung descriptor untuk satu gambar.
    
    Args:
        img: Gambar input (BGR atau grayscale)
        detector: Detektor fitur (SIFT/ORB)
    Returns:
        keypoints, descriptors
    """
    if len(img.shape) == 3:
        gray = cv2.cvtColor(img, cv2.COLOR_BGR2GRAY)
    else:
        gray = img
    
    keypoints, descriptors = detector.detectAndCompute(gray, None)
    return keypoints, descriptors


def match_features(desc1, desc2, matcher, algorithm="SIFT", ratio=0.75):
    """
    Cocokkan fitur antara dua gambar dengan Lowe's ratio test.
    
    Args:
        desc1, desc2: Descriptor dari kedua gambar
        matcher: Feature matcher
        algorithm: 'SIFT' atau 'ORB'
        ratio: Threshold Lowe's ratio test (default 0.75)
    Returns:
        List of good matches yang lolos ratio test
    """
    if desc1 is None or desc2 is None:
        return []
    
    # kNN matching dengan k=2
    matches = matcher.knnMatch(desc1, desc2, k=2)
    
    # Lowe's ratio test: buang match dengan jarak terlalu mirip
    good_matches = []
    for match_pair in matches:
        if len(match_pair) == 2:
            m, n = match_pair
            if m.distance < ratio * n.distance:
                good_matches.append(m)
    
    return good_matches


def find_homography_ransac(kp1, kp2, good_matches, min_match_count=10):
    """
    Estimasi matriks homografi H menggunakan RANSAC.
    
    Homografi H memetakan titik dari gambar 2 ke gambar 1:
        p1 = H * p2
    
    Args:
        kp1, kp2: Keypoints dari kedua gambar
        good_matches: Daftar matches yang valid
        min_match_count: Minimum jumlah matches untuk hitung homografi
    Returns:
        H (3x3 matrix) atau None jika gagal
        mask (inlier/outlier mask)
    """
    if len(good_matches) < min_match_count:
        print(f"  [Homografi] ✗ Tidak cukup matches: {len(good_matches)} < {min_match_count}")
        return None, None
    
    # Ambil koordinat titik yang cocok
    src_pts = np.float32([kp2[m.trainIdx].pt for m in good_matches]).reshape(-1, 1, 2)
    dst_pts = np.float32([kp1[m.queryIdx].pt for m in good_matches]).reshape(-1, 1, 2)
    
    # RANSAC untuk estimasi homografi yang robust
    H, mask = cv2.findHomography(src_pts, dst_pts, cv2.RANSAC, ransacReprojThreshold=5.0)
    
    if H is not None:
        inliers = int(mask.sum()) if mask is not None else 0
        print(f"  [Homografi] ✓ {inliers}/{len(good_matches)} inliers dari RANSAC")
    else:
        print("  [Homografi] ✗ Gagal menghitung homografi")
    
    return H, mask


def visualize_matches(img1, kp1, img2, kp2, good_matches, mask=None, max_draw=50):
    """
    Buat gambar visualisasi matches antar dua gambar.
    
    Args:
        img1, img2: Gambar asli
        kp1, kp2: Keypoints
        good_matches: Matches yang valid
        mask: Inlier/outlier mask dari RANSAC
        max_draw: Maksimum jumlah matches yang digambar
    Returns:
        Gambar visualisasi
    """
    draw_params = dict(
        matchColor=(0, 255, 0),       # Hijau untuk inliers
        singlePointColor=(0, 0, 255), # Merah untuk unmatched
        flags=cv2.DrawMatchesFlags_NOT_DRAW_SINGLE_POINTS
    )
    
    # Ambil subset untuk visibilitas
    if len(good_matches) > max_draw:
        indices = np.random.choice(len(good_matches), max_draw, replace=False)
        draw_matches = [good_matches[i] for i in sorted(indices)]
    else:
        draw_matches = good_matches
    
    vis = cv2.drawMatches(img1, kp1, img2, kp2, draw_matches, None, **draw_params)
    return vis


def match_image_pair(img1, img2, detector, matcher, algorithm="SIFT",
                     ratio=0.75, min_match=10, visualize=False):
    """
    Full pipeline matching untuk sepasang gambar.
    
    Returns:
        H: Matriks homografi (None jika gagal)
        kp1, kp2: Keypoints
        good_matches: Matches yang valid
        vis: Gambar visualisasi (jika visualize=True)
    """
    # Deteksi & compute
    kp1, desc1 = detect_and_compute(img1, detector)
    kp2, desc2 = detect_and_compute(img2, detector)
    
    print(f"  [Fitur] Gambar 1: {len(kp1)} kp | Gambar 2: {len(kp2)} kp")
    
    # Matching
    good_matches = match_features(desc1, desc2, matcher, algorithm, ratio)
    print(f"  [Match] {len(good_matches)} good matches (ratio={ratio})")
    
    # Homografi
    H, mask = find_homography_ransac(kp1, kp2, good_matches, min_match)
    
    # Visualisasi opsional
    vis = None
    if visualize and len(good_matches) >= min_match:
        vis = visualize_matches(img1, kp1, img2, kp2, good_matches, mask)
    
    return H, kp1, kp2, good_matches, vis
