"""
utils/image_utils.py
--------------------
Fungsi-fungsi utilitas untuk manajemen memori dan gambar:
- crop_black_borders: Menghapus sisa kanvas hitam dari panorama
- enhance_panorama: Peningkatan kontras menggunakan CLAHE
- load_images_from_folder: Load dan sort gambar
"""

import cv2
import numpy as np
import os
from pathlib import Path


def load_images_from_folder(folder_path):
    """
    Baca semua gambar dari folder dan urutkan berdasarkan nama file.
    """
    images = []
    filenames = []
    
    # Validasi folder
    if not os.path.exists(folder_path):
        print(f"[Error] Folder tidak ditemukan: {folder_path}")
        return [], []
        
    print(f"\n[Loading] Membaca gambar dari {folder_path}...")
    
    # Ekstensi yang didukung
    valid_exts = {'.jpg', '.jpeg', '.png', '.bmp', '.tif', '.tiff'}
    
    # Ambil file dan urutkan
    files = [f for f in os.listdir(folder_path) 
             if os.path.isfile(os.path.join(folder_path, f)) 
             and Path(f).suffix.lower() in valid_exts]
    files.sort()
    
    for f in files:
        file_path = os.path.join(folder_path, f)
        img = cv2.imread(file_path)
        
        if img is not None:
            # Pengecilan otomatis jika gambar terlalu besar (untuk hemat memori)
            max_dim = 1200
            h, w = img.shape[:2]
            if max(h, w) > max_dim:
                scale = max_dim / max(h, w)
                img = cv2.resize(img, (int(w * scale), int(h * scale)), interpolation=cv2.INTER_AREA)
            
            images.append(img)
            filenames.append(f)
            print(f"  ✓ Dimuat: {f} ({img.shape[1]}x{img.shape[0]})")
        else:
            print(f"  ✗ Gagal memuat: {f}")
            
    print(f"[Loading] Selesai. Total: {len(images)} gambar.")
    return images, filenames


def crop_black_borders(img):
    """
    Memotong (crop) margin latar belakang hitam dari gambar hasil warping.
    Menerapkan pencarian kontur terbesar.
    """
    # Ubah gambar menjadi grayscale
    gray = cv2.cvtColor(img, cv2.COLOR_BGR2GRAY)
    
    # Thresholding: semua pixel != 0 menjadi putih
    _, thresh = cv2.threshold(gray, 1, 255, cv2.THRESH_BINARY)
    
    # Cari contour (tepi luar bentuk panorama)
    contours, _ = cv2.findContours(thresh, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)
    
    if not contours:
        return img
        
    # Ambil contour terbesar
    largest_contour = max(contours, key=cv2.contourArea)
    
    # Ambil bounding box rect (kotak tegak) dari kontur terbesar
    x, y, w, h = cv2.boundingRect(largest_contour)
    
    # Lakukan clipping supaya hasil lebih rata
    # Cari bounding box bagian dalam (Largest Interior Rectangle - LIR)
    # Pendekatan simpel: potong sedikit margin ekstra untuk membuang batas asimetris
    y_crop_margin = max(1, int(h * 0.05))
    x_crop_margin = max(1, int(w * 0.02))
    
    y = y + y_crop_margin
    h = h - 2 * y_crop_margin
    x = x + x_crop_margin
    w = w - 2 * x_crop_margin
    
    # Pastikan ukuran tidak negatif akibat crop
    if h <= 0 or w <= 0:
        return img
        
    cropped = img[y:y+h, x:x+w]
    return cropped


def enhance_panorama(img):
    """
    Meningkatkan kontras dan detail panorama menggunakan CLAHE
    (Contrast Limited Adaptive Histogram Equalization) di channel LAB.
    """
    # 1. Konversi ke LAB color space (untuk memisahkan Lightness dari Color)
    lab = cv2.cvtColor(img, cv2.COLOR_BGR2LAB)
    l_channel, a_channel, b_channel = cv2.split(lab)
    
    # 2. Terapkan CLAHE ke L-channel (Lightness)
    clahe = cv2.createCLAHE(clipLimit=2.0, tileGridSize=(8,8))
    cl = clahe.apply(l_channel)
    
    # 3. Gabungkan kembali
    merged = cv2.merge((cl, a_channel, b_channel))
    enhanced = cv2.cvtColor(merged, cv2.COLOR_LAB2BGR)
    
    # 4. Sharpening lembut menggunakan Unsharp Masking
    gaussian = cv2.GaussianBlur(enhanced, (0, 0), 2.0)
    sharpened = cv2.addWeighted(enhanced, 1.5, gaussian, -0.5, 0)
    
    return sharpened
